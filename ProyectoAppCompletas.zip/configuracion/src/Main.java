
import Vistas.VistaMenuPrincipal;

public class Main {
    public static void main(String[] args) {
        VistaMenuPrincipal menu = new VistaMenuPrincipal();
        menu.mostrarMenu();
    }
}