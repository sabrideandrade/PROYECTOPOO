package utils;

public class Temporizador {
}
